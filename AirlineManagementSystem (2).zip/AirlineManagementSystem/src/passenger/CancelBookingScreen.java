package passenger;

import db.DBConnection;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CancelBookingScreen {
    public void show() {
        if (!CurrentPassenger.isLoggedIn()) {
            new Alert(Alert.AlertType.ERROR, "Please log in first.").show();
            return;
        }

        int passengerId = CurrentPassenger.getId();
        Stage stage = new Stage();
        stage.setTitle("Cancel Booking (ID: " + passengerId + ")");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(12);
        grid.setHgap(10);
        grid.setAlignment(Pos.CENTER);

        Label bookingIdLabel = new Label("Booking ID:");
        bookingIdLabel.getStyleClass().add("label");

        TextField bookingIdField = new TextField();
        bookingIdField.setPromptText("Enter Booking ID");
        bookingIdField.getStyleClass().add("text-field");

        Button cancelBtn = new Button("Cancel Booking");
        cancelBtn.getStyleClass().add("button");

        grid.add(bookingIdLabel, 0, 0);
        grid.add(bookingIdField, 1, 0);
        grid.add(cancelBtn, 1, 1);

        VBox root = new VBox(grid);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.getStyleClass().add("root");

        cancelBtn.setOnAction(e -> {
            int bookingId;
            try {
                bookingId = Integer.parseInt(bookingIdField.getText().trim());
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Enter a valid booking ID.").show();
                return;
            }

            String selectSql = "SELECT flight_id, seats_booked FROM bookings WHERE booking_id = ? AND passenger_id = ?";
            String deleteSql = "DELETE FROM bookings WHERE booking_id = ?";
            String updateSql = "UPDATE flights SET available_seats = available_seats + ? WHERE flight_id = ?";

            try (Connection conn = DBConnection.getConnection()) {
                conn.setAutoCommit(false);

                int flightId, seatsBooked;
                try (PreparedStatement psSel = conn.prepareStatement(selectSql)) {
                    psSel.setInt(1, bookingId);
                    psSel.setInt(2, passengerId);
                    try (ResultSet rs = psSel.executeQuery()) {
                        if (!rs.next()) {
                            conn.rollback();
                            new Alert(Alert.AlertType.ERROR, "Booking not found or not yours.").show();
                            return;
                        }
                        flightId = rs.getInt("flight_id");
                        seatsBooked = rs.getInt("seats_booked");
                    }
                }

                try (PreparedStatement psDel = conn.prepareStatement(deleteSql)) {
                    psDel.setInt(1, bookingId);
                    int d = psDel.executeUpdate();
                    if (d == 0) {
                        conn.rollback();
                        new Alert(Alert.AlertType.ERROR, "Failed to delete booking.").show();
                        return;
                    }
                }

                try (PreparedStatement psUpd = conn.prepareStatement(updateSql)) {
                    psUpd.setInt(1, seatsBooked);
                    psUpd.setInt(2, flightId);
                    int u = psUpd.executeUpdate();
                    if (u == 0) {
                        conn.rollback();
                        new Alert(Alert.AlertType.ERROR, "Failed to refund seats.").show();
                        return;
                    }
                }

                conn.commit();
                new Alert(Alert.AlertType.INFORMATION, "Booking cancelled.").show();
                stage.close();

            } catch (SQLException ex) {
                ex.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Database error: " + ex.getMessage()).show();
            }
        });

        Scene scene = new Scene(root, 400, 200);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
}











/*package passenger;

import db.DBConnection;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CancelBookingScreen {
    public void show() {
        if (!CurrentPassenger.isLoggedIn()) {
            new Alert(Alert.AlertType.ERROR, "Please log in first.").show();
            return;
        }
        int passengerId = CurrentPassenger.getId();

        Stage stage = new Stage();
        stage.setTitle("Cancel Booking (ID: " + passengerId + ")");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        TextField bookingIdField = new TextField();
        bookingIdField.setPromptText("Booking ID");
        Button cancelBtn = new Button("Cancel Booking");

        grid.add(new Label("Booking ID:"), 0, 0);
        grid.add(bookingIdField,            1, 0);
        grid.add(cancelBtn,                 1, 1);

        cancelBtn.setOnAction(e -> {
            int bookingId;
            try {
                bookingId = Integer.parseInt(bookingIdField.getText().trim());
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Enter a valid booking ID.").show();
                return;
            }

            String selectSql = "SELECT flight_id, seats_booked FROM bookings WHERE booking_id = ? AND passenger_id = ?";
            String deleteSql = "DELETE FROM bookings WHERE booking_id = ?";
            String updateSql = "UPDATE flights SET available_seats = available_seats + ? WHERE flight_id = ?";

            try (Connection conn = DBConnection.getConnection()) {
                conn.setAutoCommit(false);

                int flightId, seatsBooked;
                try (PreparedStatement psSel = conn.prepareStatement(selectSql)) {
                    psSel.setInt(1, bookingId);
                    psSel.setInt(2, passengerId);
                    try (ResultSet rs = psSel.executeQuery()) {
                        if (!rs.next()) {
                            conn.rollback();
                            new Alert(Alert.AlertType.ERROR, "Booking not found or not yours.").show();
                            return;
                        }
                        flightId   = rs.getInt("flight_id");
                        seatsBooked = rs.getInt("seats_booked");
                    }
                }

                try (PreparedStatement psDel = conn.prepareStatement(deleteSql)) {
                    psDel.setInt(1, bookingId);
                    int d = psDel.executeUpdate();
                    if (d == 0) {
                        conn.rollback();
                        new Alert(Alert.AlertType.ERROR, "Failed to delete booking.").show();
                        return;
                    }
                }

                try (PreparedStatement psUpd = conn.prepareStatement(updateSql)) {
                    psUpd.setInt(1, seatsBooked);
                    psUpd.setInt(2, flightId);
                    int u = psUpd.executeUpdate();
                    if (u == 0) {
                        conn.rollback();
                        new Alert(Alert.AlertType.ERROR, "Failed to refund seats.").show();
                        return;
                    }
                }

                conn.commit();
                new Alert(Alert.AlertType.INFORMATION, "Booking cancelled.").show();
                stage.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Database error: " + ex.getMessage()).show();
            }
        });

        stage.setScene(new Scene(grid, 400, 200));
        stage.show();
    }
}*/