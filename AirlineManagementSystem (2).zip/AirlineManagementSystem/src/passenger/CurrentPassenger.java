package passenger;

public class CurrentPassenger {
    private static int passengerId = -1;

    public static void setId(int id) {
        passengerId = id;
    }

    public static int getId() {
        return passengerId;
    }

    public static boolean isLoggedIn() {
        return passengerId > 0;
    }
}