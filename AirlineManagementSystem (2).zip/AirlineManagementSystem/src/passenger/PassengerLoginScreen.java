
package passenger;

import db.DBConnection;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PassengerLoginScreen {

    public void show() {
        Stage stage = new Stage();
        stage.setTitle("Passenger Login or Register");

        Label label = new Label("Enter Passenger ID or Email:");
        label.setStyle("-fx-font-size: 14px; -fx-text-fill: #003366;");

        TextField loginField = new TextField();
        loginField.setPromptText("Passenger ID or Email");
        loginField.setMaxWidth(220);

        Button loginBtn = new Button("Log In");
        Button registerBtn = new Button("Register New");

        loginBtn.setStyle("-fx-background-color: #007bff; -fx-text-fill: white;");
        registerBtn.setStyle("-fx-background-color: #28a745; -fx-text-fill: white;");

        HBox buttons = new HBox(10, loginBtn, registerBtn);
        buttons.setAlignment(Pos.CENTER);

        VBox layout = new VBox(15, label, loginField, buttons);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #f0f8ff;");

        loginBtn.setOnAction(e -> {
            String input = loginField.getText().trim();
            if (input.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Please enter Passenger ID or Email.");
                return;
            }

            String sql;
            boolean isEmail = input.contains("@");
            try (Connection conn = DBConnection.getConnection()) {
                if (isEmail) {
                    sql = "SELECT * FROM passengers WHERE email = ?";
                } else {
                    sql = "SELECT * FROM passengers WHERE passenger_id = ?";
                }

                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    if (isEmail) {
                        ps.setString(1, input);
                    } else {
                        ps.setInt(1, Integer.parseInt(input));
                    }

                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            int id = rs.getInt("passenger_id");
                            CurrentPassenger.setId(id);
                            new PassengerDashboardScreen().show();
                            stage.close();
                        } else {
                            showAlert(Alert.AlertType.ERROR, "Passenger not found.");
                        }
                    }
                }
            } catch (NumberFormatException nfe) {
                showAlert(Alert.AlertType.ERROR, "Invalid Passenger ID format.");
            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Database error: " + ex.getMessage());
            }
        });

        registerBtn.setOnAction(e -> new RegisterPassengerScreen().show());

        Scene scene = new Scene(layout, 380, 180);
        stage.setScene(scene);
        stage.show();
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message);
        alert.show();
    }
}









/*package passenger;

import db.DBConnection;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PassengerLoginScreen {
    public void show() {
        Stage stage = new Stage();
        stage.setTitle("Passenger Login or Register");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        Label idLabel = new Label("Passenger ID:");
        TextField idField = new TextField();
        idField.setPromptText("Enter ID to log in");
        Button loginBtn = new Button("Log In");
        Button registerBtn = new Button("Register New");

        grid.add(idLabel,   0, 0);
        grid.add(idField,   1, 0);
        HBox buttons = new HBox(10, loginBtn, registerBtn);
        grid.add(buttons,   1, 1);

        // Attempt login by ID
        loginBtn.setOnAction(e -> {
            String text = idField.getText().trim();
            int id;
            try {
                id = Integer.parseInt(text);
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Please enter a numeric ID.").show();
                return;
            }
            // Verify in DB
            String sql = "SELECT * FROM passengers WHERE passenger_id = ?";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        // success: store current passenger and open dashboard
                        CurrentPassenger.setId(id);
                        new PassengerDashboardScreen().show();
                        stage.close();
                    } else {
                        new Alert(Alert.AlertType.ERROR, "Passenger ID not found.").show();
                    }
                }
            } catch (Exception ex2) {
                ex2.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Database error: " + ex2.getMessage()).show();
            }
        });

        // Open register screen
        registerBtn.setOnAction(e -> {
            new RegisterPassengerScreen().show();
        });

        stage.setScene(new Scene(grid, 350, 150));
        stage.show();
    }
}*/
