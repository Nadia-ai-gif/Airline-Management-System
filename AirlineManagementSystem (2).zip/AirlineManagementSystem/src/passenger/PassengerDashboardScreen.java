package passenger;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PassengerDashboardScreen {
    public void show() {
        if (!CurrentPassenger.isLoggedIn()) {
            new Alert(Alert.AlertType.ERROR, "Please log in first.").show();
            return;
        }

        Stage stage = new Stage();
        stage.setTitle("Passenger Dashboard (ID: " + CurrentPassenger.getId() + ")");

        // Create buttons
        Button viewFlightsBtn    = new Button("View Flights");
        Button bookFlightBtn     = new Button("Book Flight");
        Button cancelBookingBtn  = new Button("Cancel Booking");
        Button viewMyBookingsBtn = new Button("View My Bookings");
        Button logoutBtn         = new Button("Log Out");

        // Apply CSS class to each button
        viewFlightsBtn.getStyleClass().add("button");
        bookFlightBtn.getStyleClass().add("button");
        cancelBookingBtn.getStyleClass().add("button");
        viewMyBookingsBtn.getStyleClass().add("button");
        logoutBtn.getStyleClass().add("button");

        // Set button actions
        viewFlightsBtn.setOnAction(e -> new ViewFlightsScreen().show());
        bookFlightBtn.setOnAction(e -> new BookFlightScreen().show());
        cancelBookingBtn.setOnAction(e -> new CancelBookingScreen().show());
        viewMyBookingsBtn.setOnAction(e -> new ViewMyBookingsScreen().show());

        logoutBtn.setOnAction(e -> {
            CurrentPassenger.setId(-1);
            stage.close();
            new PassengerLoginScreen().show();
        });

        // Layout
        VBox layout = new VBox(15,
            viewFlightsBtn,
            bookFlightBtn,
            cancelBookingBtn,
            viewMyBookingsBtn,
            logoutBtn
        );
        layout.setPadding(new Insets(20));
        layout.setSpacing(15);
        layout.setAlignment(Pos.CENTER); // Center align all buttons
        layout.getStyleClass().add("dashboard-screen"); // White background via CSS

        // Scene with stylesheet
        Scene scene = new Scene(layout, 400, 400); // Increased size for better spacing
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        stage.setScene(scene);
        stage.show();
    }
}










/*package passenger;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PassengerDashboardScreen {
    public void show() {
        if (!CurrentPassenger.isLoggedIn()) {
            new Alert(Alert.AlertType.ERROR, "Please log in first.").show();
            return;
        }

        Stage stage = new Stage();
        stage.setTitle("Passenger Dashboard (ID: " + CurrentPassenger.getId() + ")");

        Button viewFlightsBtn    = new Button("View Flights");
        Button bookFlightBtn     = new Button("Book Flight");
        Button cancelBookingBtn  = new Button("Cancel Booking");
        Button viewMyBookingsBtn = new Button("View My Bookings");
        Button logoutBtn         = new Button("Log Out");

        viewFlightsBtn.setOnAction(e -> new ViewFlightsScreen().show());
        bookFlightBtn.setOnAction(e -> new BookFlightScreen().show());
        cancelBookingBtn.setOnAction(e -> new CancelBookingScreen().show());
        viewMyBookingsBtn.setOnAction(e -> new ViewMyBookingsScreen().show());

        // Log out clears current passenger and returns to login screen
        logoutBtn.setOnAction(e -> {
            CurrentPassenger.setId(-1);
            stage.close();
            new PassengerLoginScreen().show();
        });

        VBox layout = new VBox(15,
            viewFlightsBtn,
            bookFlightBtn,
            cancelBookingBtn,
            viewMyBookingsBtn,
            logoutBtn
        );
        layout.setPadding(new Insets(20));
        layout.setSpacing(15);

        stage.setScene(new Scene(layout, 300, 300));
        stage.show();
    }
}*/







