package passenger;

import db.DBConnection;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;

public class RegisterPassengerScreen {
    public void show() {
        Stage stage = new Stage();
        stage.setTitle("Register Passenger");

        // GridPane for form fields
        GridPane grid = new GridPane();
        grid.setVgap(12);
        grid.setHgap(10);
        grid.setPadding(new Insets(20));
        grid.setAlignment(Pos.CENTER); // Center-align content

        Label nameLabel = new Label("Name:");
        nameLabel.getStyleClass().add("label");

        TextField nameField = new TextField();
        nameField.setPromptText("Full Name");
        nameField.getStyleClass().add("text-field");

        Label emailLabel = new Label("Email:");
        emailLabel.getStyleClass().add("label");

        TextField emailField = new TextField();
        emailField.setPromptText("email@example.com");
        emailField.getStyleClass().add("text-field");

        Label phoneLabel = new Label("Phone:");
        phoneLabel.getStyleClass().add("label");

        TextField phoneField = new TextField();
        phoneField.setPromptText("Optional");
        phoneField.getStyleClass().add("text-field");

        Button registerBtn = new Button("Register");
        registerBtn.getStyleClass().add("button");

        // Add fields to grid
        grid.add(nameLabel, 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(emailLabel, 0, 1);
        grid.add(emailField, 1, 1);
        grid.add(phoneLabel, 0, 2);
        grid.add(phoneField, 1, 2);
        grid.add(registerBtn, 1, 3);

        // Wrap in VBox for vertical centering
        VBox root = new VBox(grid);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.getStyleClass().add("root"); // white background class

        registerBtn.setOnAction(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();

            if (name.isEmpty() || email.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Name and Email are required.").show();
                return;
            }

            String sql = "INSERT INTO passengers (name, email, phone) VALUES (?, ?, ?)";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

                stmt.setString(1, name);
                stmt.setString(2, email);
                if (phone.isEmpty()) stmt.setNull(3, Types.VARCHAR);
                else stmt.setString(3, phone);

                int rows = stmt.executeUpdate();
                if (rows == 0) {
                    new Alert(Alert.AlertType.ERROR, "Registration failed.").show();
                    return;
                }

                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        int newId = rs.getInt(1);
                        new Alert(Alert.AlertType.INFORMATION,
                                "Registration successful!\nYour ID: " + newId).show();

                        CurrentPassenger.setId(newId);
                        new PassengerDashboardScreen().show();
                        stage.close();
                    } else {
                        new Alert(Alert.AlertType.ERROR, "Could not retrieve Passenger ID.").show();
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                if (ex.getErrorCode() == 1062) {
                    new Alert(Alert.AlertType.ERROR, "Email already registered.").show();
                } else {
                    new Alert(Alert.AlertType.ERROR, "Database error:\n" + ex.getMessage()).show();
                }
            }
        });

        Scene scene = new Scene(root, 450, 300);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
}













/*package passenger;

import db.DBConnection;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RegisterPassengerScreen {
    public void show() {
        Stage stage = new Stage();
        stage.setTitle("Register Passenger");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        TextField nameField  = new TextField();
        TextField emailField = new TextField();
        TextField phoneField = new TextField();
        nameField.setPromptText("Full Name");
        emailField.setPromptText("email@example.com");
        phoneField.setPromptText("Optional");

        grid.add(new Label("Name:"),  0, 0);
        grid.add(nameField,             1, 0);
        grid.add(new Label("Email:"), 0, 1);
        grid.add(emailField,            1, 1);
        grid.add(new Label("Phone:"), 0, 2);
        grid.add(phoneField,            1, 2);

        Button registerBtn = new Button("Register");
        grid.add(registerBtn, 1, 3);

        registerBtn.setOnAction(e -> {
            String name  = nameField.getText().trim();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();

            if (name.isEmpty() || email.isEmpty()) {
                new Alert(Alert.AlertType.ERROR, "Name and Email are required.").show();
                return;
            }

            String sql = "INSERT INTO passengers (name, email, phone) VALUES (?, ?, ?)";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

                stmt.setString(1, name);
                stmt.setString(2, email);
                if (phone.isEmpty()) stmt.setNull(3, java.sql.Types.VARCHAR);
                else stmt.setString(3, phone);

                int rows = stmt.executeUpdate();
                if (rows == 0) {
                    new Alert(Alert.AlertType.ERROR, "Registration failed.").show();
                    return;
                }

                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        int newId = rs.getInt(1);
                        new Alert(Alert.AlertType.INFORMATION,
                                  "Registration successful!\nYour ID: " + newId).show();

                        // Auto-login and open dashboard
                        CurrentPassenger.setId(newId);
                        new PassengerDashboardScreen().show();
                        stage.close();
                    } else {
                        new Alert(Alert.AlertType.ERROR, "Could not retrieve Passenger ID.").show();
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                if (ex.getErrorCode() == 1062) {
                    new Alert(Alert.AlertType.ERROR, "Email already registered.").show();
                } else {
                    new Alert(Alert.AlertType.ERROR, "Database error:\n" + ex.getMessage()).show();
                }
            }
        });

        stage.setScene(new Scene(grid, 400, 250));
        stage.show();
    }
}*/