package passenger;

import db.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Booking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewMyBookingsScreen {
    public void show() {
        if (!CurrentPassenger.isLoggedIn()) return;
        int passengerId = CurrentPassenger.getId();

        Stage stage = new Stage();
        stage.setTitle("My Bookings (Passenger ID: " + passengerId + ")");

        TableView<Booking> table = new TableView<>();
        ObservableList<Booking> data = FXCollections.observableArrayList();

        TableColumn<Booking, Integer> bookingIdCol = new TableColumn<>("Booking ID");
        bookingIdCol.setCellValueFactory(new PropertyValueFactory<>("bookingId"));

        TableColumn<Booking, Integer> flightIdCol = new TableColumn<>("Flight ID");
        flightIdCol.setCellValueFactory(new PropertyValueFactory<>("flightId"));

        TableColumn<Booking, Integer> seatsCol = new TableColumn<>("Seats Booked");
        seatsCol.setCellValueFactory(new PropertyValueFactory<>("seatsBooked"));

        TableColumn<Booking, String> dateCol = new TableColumn<>("Booking Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("bookingDate"));

        table.getColumns().addAll(bookingIdCol, flightIdCol, seatsCol, dateCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setStyle("-fx-font-size: 14px;");

        String sql = "SELECT * FROM bookings WHERE passenger_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, passengerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Booking b = new Booking(
                            rs.getInt("booking_id"),
                            rs.getInt("flight_id"),
                            rs.getInt("seats_booked"),
                            rs.getString("booking_date")
                    );
                    data.add(b);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        table.setItems(data);

        Label heading = new Label("My Bookings");
        heading.getStyleClass().add("heading");

        VBox vbox = new VBox(15, heading, table);
        vbox.setPadding(new Insets(25));
        vbox.setAlignment(Pos.CENTER);
        vbox.getStyleClass().add("root");

        Scene scene = new Scene(vbox, 600, 400);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
}













/*package passenger;

import db.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Booking;
public class ViewMyBookingsScreen {
    public void show() {
        if (!CurrentPassenger.isLoggedIn()) return;
        int passengerId = CurrentPassenger.getId();

        Stage stage = new Stage();
        stage.setTitle("My Bookings (ID: " + passengerId + ")");

        TableView<Booking> table = new TableView<>();
        ObservableList<Booking> data = FXCollections.observableArrayList();

        TableColumn<Booking, Integer> bookingIdCol  = new TableColumn<>("Booking ID");
        bookingIdCol.setCellValueFactory(new PropertyValueFactory<>("bookingId"));

        TableColumn<Booking, Integer> flightIdCol   = new TableColumn<>("Flight ID");
        flightIdCol.setCellValueFactory(new PropertyValueFactory<>("flightId"));

        TableColumn<Booking, Integer> seatsCol      = new TableColumn<>("Seats Booked");
        seatsCol.setCellValueFactory(new PropertyValueFactory<>("seatsBooked"));

        TableColumn<Booking, String> dateCol        = new TableColumn<>("Booking Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("bookingDate"));

        table.getColumns().addAll(bookingIdCol, flightIdCol, seatsCol, dateCol);

        String sql = "SELECT * FROM bookings WHERE passenger_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, passengerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Booking b = new Booking(
                        rs.getInt("booking_id"),
                        rs.getInt("flight_id"),
                        rs.getInt("seats_booked"),
                        rs.getString("booking_date")
                    );
                    data.add(b);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        table.setItems(data);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        VBox vbox = new VBox(10, table);
        vbox.setPadding(new Insets(20));
        stage.setScene(new Scene(vbox, 600, 400));
        stage.show();
    }
}*/
