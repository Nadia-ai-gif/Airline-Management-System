package passenger;

import db.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import model.Flight;
public class ViewFlightsScreen {
    public void show() {
        Stage stage = new Stage();
        stage.setTitle("Available Flights");

        TableView<Flight> table = new TableView<>();
        ObservableList<Flight> data = FXCollections.observableArrayList();

        TableColumn<Flight, Integer> idCol = new TableColumn<>("Flight ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("flightId"));

        TableColumn<Flight, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("flightName"));

        TableColumn<Flight, String> srcCol = new TableColumn<>("Source");
        srcCol.setCellValueFactory(new PropertyValueFactory<>("source"));

        TableColumn<Flight, String> destCol = new TableColumn<>("Destination");
        destCol.setCellValueFactory(new PropertyValueFactory<>("destination"));

        TableColumn<Flight, String> depCol = new TableColumn<>("Departure");
        depCol.setCellValueFactory(new PropertyValueFactory<>("departureTime"));

        TableColumn<Flight, String> arrCol = new TableColumn<>("Arrival");
        arrCol.setCellValueFactory(new PropertyValueFactory<>("arrivalTime"));

        TableColumn<Flight, Double> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Flight, Integer> totalSeatsCol = new TableColumn<>("Total Seats");
        totalSeatsCol.setCellValueFactory(new PropertyValueFactory<>("totalSeats"));

        TableColumn<Flight, Integer> availSeatsCol = new TableColumn<>("Available Seats");
        availSeatsCol.setCellValueFactory(new PropertyValueFactory<>("availableSeats"));

        table.getColumns().addAll(
            idCol, nameCol, srcCol, destCol,
            depCol, arrCol, priceCol, totalSeatsCol, availSeatsCol
        );

        String sql = "SELECT * FROM flights";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Flight f = new Flight(
                    rs.getInt("flight_id"),
                    rs.getString("flight_name"),
                    rs.getString("source"),
                    rs.getString("destination"),
                    rs.getString("departure_time"),
                    rs.getString("arrival_time"),
                    rs.getDouble("price"),
                    rs.getInt("total_seats"),
                    rs.getInt("available_seats")
                );
                data.add(f);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        table.setItems(data);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        VBox vbox = new VBox(10, table);
        vbox.setPadding(new Insets(20));

        stage.setScene(new Scene(vbox, 800, 400));
        stage.show();
    }
} 









/*package passenger;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Flight;  // Flight POJO class you'll need
import db.DBConnection; // Your DB connection helper
import model.Flight;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewFlightsScreen {

    private TableView<Flight> table;

    public void start(Stage stage) {
        stage.setTitle("Available Flights");

        table = new TableView<>();
        setupTableColumns();

        ObservableList<Flight> flights = fetchFlightsFromDB();
        table.setItems(flights);

        VBox layout = new VBox(10, table);
        layout.setAlignment(Pos.CENTER);
        layout.setPrefWidth(700);
        layout.setPrefHeight(400);

        Scene scene = new Scene(layout);
        stage.setScene(scene);
        stage.show();
    }

    private void setupTableColumns() {
        TableColumn<Flight, String> flightNoCol = new TableColumn<>("Flight Number");
        flightNoCol.setCellValueFactory(new PropertyValueFactory<>("flightNumber"));

        TableColumn<Flight, String> sourceCol = new TableColumn<>("Source");
        sourceCol.setCellValueFactory(new PropertyValueFactory<>("source"));

        TableColumn<Flight, String> destCol = new TableColumn<>("Destination");
        destCol.setCellValueFactory(new PropertyValueFactory<>("destination"));

        TableColumn<Flight, String> dateTimeCol = new TableColumn<>("Departure Time");
        dateTimeCol.setCellValueFactory(new PropertyValueFactory<>("departureTime"));

        TableColumn<Flight, Double> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Flight, Integer> seatsCol = new TableColumn<>("Seats");
        seatsCol.setCellValueFactory(new PropertyValueFactory<>("seats"));

        table.getColumns().addAll(flightNoCol, sourceCol, destCol, dateTimeCol, priceCol, seatsCol);
    }

    private ObservableList<Flight> fetchFlightsFromDB() {
        ObservableList<Flight> list = FXCollections.observableArrayList();

        String sql = "SELECT * FROM flights";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

        	Flight flight = new Flight(
        		    rs.getInt("flight_id"),              // <- changed here
        		    rs.getString("flight_number"),
        		    rs.getString("source"),
        		    rs.getString("destination"),
        		    rs.getString("departure_time"),
        		    sql, rs.getDouble("price"),
        		    rs.getInt("seats"), 0
        		);

                list.add(flight);
            

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
*/