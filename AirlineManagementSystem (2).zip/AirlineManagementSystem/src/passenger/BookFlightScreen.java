package passenger;

import db.DBConnection;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookFlightScreen {
    public void show() {
        if (!CurrentPassenger.isLoggedIn()) {
            new Alert(Alert.AlertType.ERROR, "Please log in first.").show();
            return;
        }

        Stage stage = new Stage();
        stage.setTitle("Book a Flight (Passenger ID: " + CurrentPassenger.getId() + ")");

        // Form layout
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(12);
        grid.setHgap(10);
        grid.setAlignment(Pos.CENTER);

        Label flightIdLabel = new Label("Flight ID:");
        flightIdLabel.getStyleClass().add("label");
        TextField flightIdField = new TextField();
        flightIdField.setPromptText("Enter Flight ID");
        flightIdField.getStyleClass().add("text-field");

        Label seatsLabel = new Label("Seats:");
        seatsLabel.getStyleClass().add("label");
        TextField seatsField = new TextField();
        seatsField.setPromptText("Number of seats");
        seatsField.getStyleClass().add("text-field");

        Button bookButton = new Button("Book Flight");
        bookButton.getStyleClass().add("button");

        // Add to grid
        grid.add(flightIdLabel, 0, 0);
        grid.add(flightIdField, 1, 0);
        grid.add(seatsLabel, 0, 1);
        grid.add(seatsField, 1, 1);
        grid.add(bookButton, 1, 2);

        // Wrap in VBox for centering
        VBox root = new VBox(grid);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.getStyleClass().add("root"); // Apply white background

        bookButton.setOnAction(e -> {
            int flightId = -1, seatsToBook = -1;
            try {
                flightId = Integer.parseInt(flightIdField.getText().trim());
                seatsToBook = Integer.parseInt(seatsField.getText().trim());
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Please enter valid numbers.").show();
                return;
            }

            String checkSql = "SELECT available_seats FROM flights WHERE flight_id = ?";
            String bookSql = "INSERT INTO bookings (passenger_id, flight_id, seats_booked) VALUES (?, ?, ?)";
            String updateSql = "UPDATE flights SET available_seats = ? WHERE flight_id = ?";
            int passengerId = CurrentPassenger.getId();

            try (Connection conn = DBConnection.getConnection()) {
                conn.setAutoCommit(false);

                int availableSeats;
                try (PreparedStatement psCheck = conn.prepareStatement(checkSql)) {
                    psCheck.setInt(1, flightId);
                    try (ResultSet rs = psCheck.executeQuery()) {
                        if (!rs.next()) {
                            conn.rollback();
                            new Alert(Alert.AlertType.ERROR, "Flight not found.").show();
                            return;
                        }
                        availableSeats = rs.getInt("available_seats");
                    }
                }

                if (seatsToBook > availableSeats) {
                    conn.rollback();
                    new Alert(Alert.AlertType.ERROR, "Not enough seats available.").show();
                    return;
                }

                try (PreparedStatement psBook = conn.prepareStatement(bookSql)) {
                    psBook.setInt(1, passengerId);
                    psBook.setInt(2, flightId);
                    psBook.setInt(3, seatsToBook);
                    int r1 = psBook.executeUpdate();
                    if (r1 == 0) {
                        conn.rollback();
                        new Alert(Alert.AlertType.ERROR, "Booking failed.").show();
                        return;
                    }
                }

                try (PreparedStatement psUpdate = conn.prepareStatement(updateSql)) {
                    psUpdate.setInt(1, availableSeats - seatsToBook);
                    psUpdate.setInt(2, flightId);
                    int r2 = psUpdate.executeUpdate();
                    if (r2 == 0) {
                        conn.rollback();
                        new Alert(Alert.AlertType.ERROR, "Failed to update seat count.").show();
                        return;
                    }
                }

                conn.commit();
                new Alert(Alert.AlertType.INFORMATION, "Booking successful!").show();
                stage.close();

            } catch (SQLException ex) {
                ex.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Database error: " + ex.getMessage()).show();
            }
        });

        Scene scene = new Scene(root, 450, 250);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
}















/*package passenger;

import db.DBConnection;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookFlightScreen {
    public void show() {
        if (!CurrentPassenger.isLoggedIn()) {
            new Alert(Alert.AlertType.ERROR, "Please log in first.").show();
            return;
        }

        Stage stage = new Stage();
        stage.setTitle("Book a Flight (Passenger ID: " + CurrentPassenger.getId() + ")");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        TextField flightIdField = new TextField();
        TextField seatsField    = new TextField();
        flightIdField.setPromptText("Flight ID");
        seatsField.setPromptText("Number of seats");

        grid.add(new Label("Flight ID:"), 0, 0);
        grid.add(flightIdField,            1, 0);
        grid.add(new Label("Seats:"),     0, 1);
        grid.add(seatsField,               1, 1);

        Button bookButton = new Button("Book Flight");
        grid.add(bookButton,               1, 2);

        bookButton.setOnAction(e -> {
            int flightId = -1, seatsToBook = -1;
            try {
                flightId = Integer.parseInt(flightIdField.getText().trim());
                seatsToBook = Integer.parseInt(seatsField.getText().trim());
            } catch (NumberFormatException ex) {
                new Alert(Alert.AlertType.ERROR, "Please enter valid numbers.").show();
                return;
            }

            String checkSql = "SELECT available_seats FROM flights WHERE flight_id = ?";
            String bookSql  = "INSERT INTO bookings (passenger_id, flight_id, seats_booked) VALUES (?, ?, ?)";
            String updateSql = "UPDATE flights SET available_seats = ? WHERE flight_id = ?";
            int passengerId = CurrentPassenger.getId();

            try (Connection conn = DBConnection.getConnection()) {
                conn.setAutoCommit(false);

                int availableSeats;
                try (PreparedStatement psCheck = conn.prepareStatement(checkSql)) {
                    psCheck.setInt(1, flightId);
                    try (ResultSet rs = psCheck.executeQuery()) {
                        if (!rs.next()) {
                            conn.rollback();
                            new Alert(Alert.AlertType.ERROR, "Flight not found.").show();
                            return;
                        }
                        availableSeats = rs.getInt("available_seats");
                    }
                }

                if (seatsToBook > availableSeats) {
                    conn.rollback();
                    new Alert(Alert.AlertType.ERROR, "Not enough seats.").show();
                    return;
                }

                try (PreparedStatement psBook = conn.prepareStatement(bookSql)) {
                    psBook.setInt(1, passengerId);
                    psBook.setInt(2, flightId);
                    psBook.setInt(3, seatsToBook);
                    int r1 = psBook.executeUpdate();
                    if (r1 == 0) {
                        conn.rollback();
                        new Alert(Alert.AlertType.ERROR, "Booking failed.").show();
                        return;
                    }
                }

                try (PreparedStatement psUpdate = conn.prepareStatement(updateSql)) {
                    psUpdate.setInt(1, availableSeats - seatsToBook);
                    psUpdate.setInt(2, flightId);
                    int r2 = psUpdate.executeUpdate();
                    if (r2 == 0) {
                        conn.rollback();
                        new Alert(Alert.AlertType.ERROR, "Failed to update seats.").show();
                        return;
                    }
                }

                conn.commit();
                new Alert(Alert.AlertType.INFORMATION, "Booking successful!").show();
                stage.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Database error: " + ex.getMessage()).show();
            }
        });

        stage.setScene(new Scene(grid, 450, 250));
        stage.show();
    }
}*/
