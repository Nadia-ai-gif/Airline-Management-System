// Package: model

package model;

public class Flight {
    private int flightId;
    private String flightName;
    private String source;
    private String destination;
    private String departureTime;
    private String arrivalTime;
    private double price;
    private int totalSeats;
    private int availableSeats;

    public Flight(int flightId, String flightName, String source, String destination, String departureTime, String arrivalTime, double price, int totalSeats, int availableSeats) {
        this.flightId = flightId;
        this.flightName = flightName;
        this.source = source;
        this.destination = destination;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.price = price;
        this.totalSeats = totalSeats;
        this.availableSeats = availableSeats;
    }

    // Getters and setters for all fields (optional for simplicity)
    public int getFlightId() { return flightId; }
    public String getFlightName() { return flightName; }
    public String getSource() { return source; }
    public String getDestination() { return destination; }
    public String getDepartureTime() { return departureTime; }
    public String getArrivalTime() { return arrivalTime; }
    public double getPrice() { return price; }
    public int getTotalSeats() { return totalSeats; }
    public int getAvailableSeats() { return availableSeats; }

    public void setAvailableSeats(int seats) { this.availableSeats = seats; }
}

// Similarly, create Passenger.java and Booking.java in the same package.

