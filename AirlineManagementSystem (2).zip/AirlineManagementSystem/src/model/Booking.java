package model;

public class Booking {
    private int bookingId;
    private int flightId;
    private int seatsBooked;
    private String bookingDate;

    // Constructor
    public Booking(int bookingId, int flightId, int seatsBooked, String bookingDate) {
        this.bookingId = bookingId;
        this.flightId = flightId;
        this.seatsBooked = seatsBooked;
        this.bookingDate = bookingDate;
    }

    // Getters
    public int getBookingId() {
        return bookingId;
    }

    public int getFlightId() {
        return flightId;
    }

    public int getSeatsBooked() {
        return seatsBooked;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    // Optional: toString() for debugging
    @Override
    public String toString() {
        return "Booking [ID=" + bookingId + ", Flight=" + flightId + ", Seats=" + seatsBooked + ", Date=" + bookingDate + "]";
    }
}







/*package model;



public class Booking {
    private int bookingId;
    private int passengerId;
    private int flightId;
    private int seatsBooked;
    private String bookingDate;

    public Booking(int bookingId, int passengerId, int flightId, int seatsBooked, String bookingDate) {
        this.bookingId = bookingId;
        this.passengerId = passengerId;
        this.flightId = flightId;
        this.seatsBooked = seatsBooked;
        this.bookingDate = bookingDate;
    }

    public int getBookingId() { return bookingId; }
    public int getPassengerId() { return passengerId; }
    public int getFlightId() { return flightId; }
    public int getSeatsBooked() { return seatsBooked; }
    public String getBookingDate() { return bookingDate; }
}*/