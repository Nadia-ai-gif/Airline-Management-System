package admin;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;
import db.DBConnection;

public class AdminViewFlightsScreen extends Application {

    // Flight model class
    public class Flight {
        private int flightId;
        private String flightName;
        private String source;
        private String destination;
        private String departureTime;
        private String arrivalTime;
        private double price;
        private int totalSeats;

        public Flight(int flightId, String flightName, String source, String destination,
                      String departureTime, String arrivalTime, double price, int totalSeats) {
            this.flightId = flightId;
            this.flightName = flightName;
            this.source = source;
            this.destination = destination;
            this.departureTime = departureTime;
            this.arrivalTime = arrivalTime;
            this.price = price;
            this.totalSeats = totalSeats;
        }

        public int getFlightId() { return flightId; }
        public String getFlightName() { return flightName; }
        public String getSource() { return source; }
        public String getDestination() { return destination; }
        public String getDepartureTime() { return departureTime; }
        public String getArrivalTime() { return arrivalTime; }
        public double getPrice() { return price; }
        public int getTotalSeats() { return totalSeats; }
    }

    @Override
    public void start(Stage primaryStage) {
        TableView<Flight> table = new TableView<>();

        TableColumn<Flight, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("flightId"));

        TableColumn<Flight, String> nameCol = new TableColumn<>("Flight Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("flightName"));

        TableColumn<Flight, String> sourceCol = new TableColumn<>("Source");
        sourceCol.setCellValueFactory(new PropertyValueFactory<>("source"));

        TableColumn<Flight, String> destCol = new TableColumn<>("Destination");
        destCol.setCellValueFactory(new PropertyValueFactory<>("destination"));

        TableColumn<Flight, String> depTimeCol = new TableColumn<>("Departure Time");
        depTimeCol.setCellValueFactory(new PropertyValueFactory<>("departureTime"));

        TableColumn<Flight, String> arrTimeCol = new TableColumn<>("Arrival Time");
        arrTimeCol.setCellValueFactory(new PropertyValueFactory<>("arrivalTime"));

        TableColumn<Flight, Double> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Flight, Integer> seatsCol = new TableColumn<>("Total Seats");
        seatsCol.setCellValueFactory(new PropertyValueFactory<>("totalSeats"));

      /*  table.getColumns().addAll(idCol, nameCol, sourceCol, destCol, depTimeCol, arrTimeCol, priceCol, seatsCol);
        table.setItems(getFlights());*/
        table.getColumns().addAll(idCol, nameCol, sourceCol, destCol, depTimeCol, arrTimeCol, priceCol, seatsCol);

     // Fix: Prevent extra column
     table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

     table.setItems(getFlights());


        VBox vbox = new VBox(table);
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(15);
        vbox.setStyle("-fx-padding: 20;");

        StackPane root = new StackPane(vbox);
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("root");

        Scene scene = new Scene(root, 900, 500);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        primaryStage.setTitle("Admin - View All Flights");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private ObservableList<Flight> getFlights() {
        ObservableList<Flight> list = FXCollections.observableArrayList();
        String query = "SELECT * FROM flights";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                list.add(new Flight(
                        rs.getInt("flight_id"),
                        rs.getString("flight_name"),
                        rs.getString("source"),
                        rs.getString("destination"),
                        rs.getString("departure_time"),
                        rs.getString("arrival_time"),
                        rs.getDouble("price"),
                        rs.getInt("total_seats")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
















/*package admin;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;
import db.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AdminViewFlightsScreen extends Application {

    public class Flight {
        private int flightId;
        private String flightName, source, destination, time;
        private double price;
        private int seats;

        public Flight(int flightId, String flightName, String source, String destination, String time, double price, int seats) {
            this.flightId = flightId;
            this.flightName = flightName;
            this.source = source;
            this.destination = destination;
            this.time = time;
            this.price = price;
            this.seats = seats;
        }

        public int getFlightId() { return flightId; }
        public String getFlightName() { return flightName; }
        public String getSource() { return source; }
        public String getDestination() { return destination; }
        public String getTime() { return time; }
        public double getPrice() { return price; }
        public int getSeats() { return seats; }
    }

    @Override
    public void start(Stage primaryStage) {
        TableView<Flight> table = new TableView<>();

        TableColumn<Flight, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("flightId"));

        TableColumn<Flight, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("flightName"));

        TableColumn<Flight, String> sourceCol = new TableColumn<>("Source");
        sourceCol.setCellValueFactory(new PropertyValueFactory<>("source"));

        TableColumn<Flight, String> destCol = new TableColumn<>("Destination");
        destCol.setCellValueFactory(new PropertyValueFactory<>("destination"));

        TableColumn<Flight, String> timeCol = new TableColumn<>("Time");
        timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));

        TableColumn<Flight, Double> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Flight, Integer> seatsCol = new TableColumn<>("Seats");
        seatsCol.setCellValueFactory(new PropertyValueFactory<>("seats"));

        table.getColumns().addAll(idCol, nameCol, sourceCol, destCol, timeCol, priceCol, seatsCol);
        table.setItems(getFlights());

        VBox layout = new VBox(table);
        primaryStage.setScene(new Scene(layout, 700, 400));
        primaryStage.setTitle("Flight List");
        primaryStage.show();
    }

    private ObservableList<Flight> getFlights() {
        ObservableList<Flight> list = FXCollections.observableArrayList();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM flights")) {

            while (rs.next()) {
                list.add(new Flight(
                        rs.getInt("flight_id"),
                        rs.getString("flight_name"),
                        rs.getString("source"),
                        rs.getString("destination"),
                        rs.getString("departure_time"),
                        rs.getDouble("price"),
                        rs.getInt("total_seats")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}*/
