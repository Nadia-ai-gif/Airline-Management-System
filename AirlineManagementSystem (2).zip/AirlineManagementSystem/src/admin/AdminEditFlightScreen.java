package admin;

import db.DBConnection;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.sql.*;

public class AdminEditFlightScreen extends Application {
    private TextField flightIdField, nameField, sourceField, destinationField,
                      depTimeField, arrTimeField, priceField, seatsField;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Edit Flight");

        Label heading = new Label("Edit Flight Details");
        heading.getStyleClass().add("title-text");

        Label idLabel = new Label("Enter Flight ID:");
        flightIdField = new TextField();
        flightIdField.getStyleClass().add("text-field");

        Button loadButton = new Button("Load");
        loadButton.getStyleClass().add("button");

        GridPane form = new GridPane();
        form.setVgap(10);
        form.setHgap(10);
        form.setAlignment(Pos.CENTER);

        nameField = new TextField();
        sourceField = new TextField();
        destinationField = new TextField();
        depTimeField = new TextField();
        arrTimeField = new TextField();
        priceField = new TextField();
        seatsField = new TextField();

        nameField.getStyleClass().add("text-field");
        sourceField.getStyleClass().add("text-field");
        destinationField.getStyleClass().add("text-field");
        depTimeField.getStyleClass().add("text-field");
        arrTimeField.getStyleClass().add("text-field");
        priceField.getStyleClass().add("text-field");
        seatsField.getStyleClass().add("text-field");

        form.add(new Label("Flight Name:"), 0, 0); form.add(nameField, 1, 0);
        form.add(new Label("Source:"), 0, 1); form.add(sourceField, 1, 1);
        form.add(new Label("Destination:"), 0, 2); form.add(destinationField, 1, 2);
        form.add(new Label("Departure Time:"), 0, 3); form.add(depTimeField, 1, 3);
        form.add(new Label("Arrival Time:"), 0, 4); form.add(arrTimeField, 1, 4);
        form.add(new Label("Price:"), 0, 5); form.add(priceField, 1, 5);
        form.add(new Label("Total Seats:"), 0, 6); form.add(seatsField, 1, 6);

        Button updateButton = new Button("Update Flight");
        updateButton.getStyleClass().add("button");

        loadButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(flightIdField.getText());
                populateFields(id);
            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Please enter a valid flight ID.");
            }
        });

        updateButton.setOnAction(e -> updateFlight());

        VBox layout = new VBox(15, heading, idLabel, flightIdField, loadButton, form, updateButton);
        layout.getStyleClass().add("root");
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout, 500, 600);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm()); // Ensure path is correct
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void populateFields(int flightId) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM flights WHERE flight_id = ?")) {
            stmt.setInt(1, flightId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                nameField.setText(rs.getString("flight_name"));
                sourceField.setText(rs.getString("source"));
                destinationField.setText(rs.getString("destination"));
                depTimeField.setText(rs.getString("departure_time"));
                arrTimeField.setText(rs.getString("arrival_time"));
                priceField.setText(rs.getString("price"));
                seatsField.setText(rs.getString("total_seats"));
            } else {
                showAlert(Alert.AlertType.WARNING, "Flight ID not found.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error loading flight data.");
        }
    }

    private void updateFlight() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE flights SET flight_name=?, source=?, destination=?, departure_time=?, arrival_time=?, price=?, total_seats=? WHERE flight_id=?")) {

            stmt.setString(1, nameField.getText());
            stmt.setString(2, sourceField.getText());
            stmt.setString(3, destinationField.getText());
            stmt.setString(4, depTimeField.getText());
            stmt.setString(5, arrTimeField.getText());
            stmt.setDouble(6, Double.parseDouble(priceField.getText()));
            stmt.setInt(7, Integer.parseInt(seatsField.getText()));
            stmt.setInt(8, Integer.parseInt(flightIdField.getText()));

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Flight updated successfully.");
            } else {
                showAlert(Alert.AlertType.WARNING, "No changes made or flight ID invalid.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Failed to update flight.");
        }
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message);
        alert.showAndWait();
    }
}
     












 /*package admin;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;
import db.DBConnection;

public class AdminEditFlightScreen extends Application {
    private TextField flightIdField, nameField, sourceField, destinationField, timeField, priceField, seatsField;

    @Override
    public void start(Stage primaryStage) {
        Label label = new Label("Enter Flight ID to Edit:");
        flightIdField = new TextField();
        Button loadButton = new Button("Load");

        nameField = new TextField();
        sourceField = new TextField();
        destinationField = new TextField();
        timeField = new TextField();
        priceField = new TextField();
        seatsField = new TextField();

        Button updateButton = new Button("Update Flight");

        loadButton.setOnAction(e -> populateFields(Integer.parseInt(flightIdField.getText())));
        updateButton.setOnAction(e -> updateFlight());

        VBox layout = new VBox(10, label, flightIdField, loadButton, nameField, sourceField, destinationField, timeField, priceField, seatsField, updateButton);
        primaryStage.setScene(new Scene(layout, 300, 400));
        primaryStage.show();
    }

    private void populateFields(int flightId) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM flights WHERE flight_id = ?")) {
            stmt.setInt(1, flightId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                nameField.setText(rs.getString("flight_name"));
                sourceField.setText(rs.getString("source"));
                destinationField.setText(rs.getString("destination"));
                timeField.setText(rs.getString("departure_time"));
                priceField.setText(rs.getString("price"));
                seatsField.setText(rs.getString("total_seats"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void updateFlight() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE flights SET flight_name=?, source=?, destination=?, departure_time=?, price=?, total_seats=? WHERE flight_id=?")) {

            stmt.setString(1, nameField.getText());
            stmt.setString(2, sourceField.getText());
            stmt.setString(3, destinationField.getText());
            stmt.setString(4, timeField.getText());
            stmt.setDouble(5, Double.parseDouble(priceField.getText()));
            stmt.setInt(6, Integer.parseInt(seatsField.getText()));
            stmt.setInt(7, Integer.parseInt(flightIdField.getText()));

            stmt.executeUpdate();
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Flight updated successfully.");
            alert.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}*/