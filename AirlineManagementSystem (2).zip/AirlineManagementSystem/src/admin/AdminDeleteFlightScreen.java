package admin;

import db.DBConnection;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class AdminDeleteFlightScreen extends Application {

    private TextField flightIdField;

    @Override
    public void start(Stage primaryStage) {
        Label label = new Label("Enter Flight ID to Delete:");
        label.setStyle("-fx-font-size: 16px; -fx-text-fill: #003366;");

        flightIdField = new TextField();
        flightIdField.setPromptText("Flight ID");
        flightIdField.setMaxWidth(200);

        Button deleteButton = new Button("Delete Flight");
        deleteButton.setStyle("-fx-background-color: #d9534f; -fx-text-fill: white; -fx-font-weight: bold;");
        deleteButton.setOnAction(e -> {
            try {
                int flightId = Integer.parseInt(flightIdField.getText());

                // Confirm before deleting
                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete this flight?",
                        ButtonType.YES, ButtonType.NO);
                confirm.showAndWait().ifPresent(response -> {
                    if (response == ButtonType.YES) {
                        deleteFlight(flightId);
                    }
                });
            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.WARNING, "Invalid input. Please enter a valid flight ID.");
            }
        });

        VBox layout = new VBox(15, label, flightIdField, deleteButton);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: #eaf4ff;");

        Scene scene = new Scene(layout, 350, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Delete Flight");
        primaryStage.show();
    }

    private void deleteFlight(int flightId) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM flights WHERE flight_id = ?")) {

            stmt.setInt(1, flightId);
            int rowsAffected = stmt.executeUpdate();
            String msg = (rowsAffected > 0) ? "Flight deleted successfully." : "Flight not found.";
            showAlert(Alert.AlertType.INFORMATION, msg);
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error deleting flight.");
        }
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message, ButtonType.OK);
        alert.show();
    }
}












/*package admin;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;
import db.DBConnection;

public class AdminDeleteFlightScreen extends Application {
    private TextField flightIdField;

    @Override
    public void start(Stage primaryStage) {
        Label label = new Label("Enter Flight ID to Delete:");
        flightIdField = new TextField();
        Button deleteButton = new Button("Delete Flight");

        deleteButton.setOnAction(e -> deleteFlight(Integer.parseInt(flightIdField.getText())));

        VBox layout = new VBox(10, label, flightIdField, deleteButton);
        primaryStage.setScene(new Scene(layout, 300, 200));
        primaryStage.setTitle("Delete Flight");
        primaryStage.show();
    }

    private void deleteFlight(int flightId) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM flights WHERE flight_id = ?")) {

            stmt.setInt(1, flightId);
            int rowsAffected = stmt.executeUpdate();
            String msg = (rowsAffected > 0) ? "Flight deleted successfully." : "Flight not found.";
            Alert alert = new Alert(Alert.AlertType.INFORMATION, msg);
            alert.show();
        } catch (Exception ex) {
            ex.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Error deleting flight.");
            alert.show();
        }
    }
}*/