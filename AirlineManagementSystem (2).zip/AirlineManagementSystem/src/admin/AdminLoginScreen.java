package admin;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class AdminLoginScreen {

    public void show() {
        Stage stage = new Stage();
        stage.setTitle("Admin Login");

        GridPane grid = new GridPane();
        grid.setVgap(15);
        grid.setHgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.setPadding(new Insets(30));

        Label userLabel = new Label("Username:");
        Label passLabel = new Label("Password:");

        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        Button loginButton = new Button("Login");

        userLabel.getStyleClass().add("label");
        passLabel.getStyleClass().add("label");
        usernameField.getStyleClass().add("text-field");
        passwordField.getStyleClass().add("password-field");
        loginButton.getStyleClass().add("button");

        grid.add(userLabel, 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(passLabel, 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(loginButton, 1, 2);

        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            if (username.equals("admin") && password.equals("admin123")) {
                stage.close();
                try {
                    new AdminDashboardScreen().show();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else {
                new Alert(Alert.AlertType.ERROR, "Invalid credentials!").show();
            }
        });

        VBox root = new VBox(grid);
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("root");

        Scene scene = new Scene(root, 400, 300);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        stage.setScene(scene);
        stage.show();
    }
}


















/*package admin;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class AdminLoginScreen {

    public void show() {
        Stage stage = new Stage();
        stage.setTitle("Admin Login");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        Button loginButton = new Button("Login");

        grid.add(new Label("Username:"), 0, 0); grid.add(usernameField, 1, 0);
        grid.add(new Label("Password:"), 0, 1); grid.add(passwordField, 1, 1);
        grid.add(loginButton, 1, 2);

        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            // Simple check (you can replace with DB logic later)
            if (username.equals("admin") && password.equals("admin123")) {
                stage.close(); // Close login
                try {
                	 new AdminDashboardScreen().show(); // Open Admin screen
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else {
                new Alert(Alert.AlertType.ERROR, "Invalid credentials!").show();
            }
        });

        stage.setScene(new Scene(grid, 300, 200));
        stage.show();
    }
}*/
