package admin;

import db.DBConnection;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class AdminFlightScreen extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Admin - Add Flight");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);
        grid.setAlignment(Pos.CENTER);  // Center alignment inside the parent
        grid.getStyleClass().add("root"); // Apply CSS class

        // Input fields
        TextField nameField = new TextField();
        TextField sourceField = new TextField();
        TextField destField = new TextField();
        TextField depTimeField = new TextField();
        TextField arrTimeField = new TextField();
        TextField priceField = new TextField();
        TextField seatsField = new TextField();

        // Add labels + fields
        grid.add(new Label("Flight Name:"), 0, 0); grid.add(nameField, 1, 0);
        grid.add(new Label("Source:"), 0, 1); grid.add(sourceField, 1, 1);
        grid.add(new Label("Destination:"), 0, 2); grid.add(destField, 1, 2);
        grid.add(new Label("Departure Time:"), 0, 3); grid.add(depTimeField, 1, 3);
        grid.add(new Label("Arrival Time:"), 0, 4); grid.add(arrTimeField, 1, 4);
        grid.add(new Label("Price:"), 0, 5); grid.add(priceField, 1, 5);
        grid.add(new Label("Total Seats:"), 0, 6); grid.add(seatsField, 1, 6);

        // Apply style to text fields
        TextField[] fields = {nameField, sourceField, destField, depTimeField, arrTimeField, priceField, seatsField};
        for (TextField tf : fields) {
            tf.getStyleClass().add("text-field");
        }

        Button addButton = new Button("Add Flight");
        addButton.getStyleClass().add("button");
        grid.add(addButton, 1, 7);

        // Button action to insert flight
        addButton.setOnAction(e -> {
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO flights (flight_name, source, destination, departure_time, arrival_time, price, total_seats, available_seats) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);

                stmt.setString(1, nameField.getText());
                stmt.setString(2, sourceField.getText());
                stmt.setString(3, destField.getText());
                stmt.setString(4, depTimeField.getText());
                stmt.setString(5, arrTimeField.getText());
                stmt.setDouble(6, Double.parseDouble(priceField.getText()));
                int seats = Integer.parseInt(seatsField.getText());
                stmt.setInt(7, seats);
                stmt.setInt(8, seats); // available seats = total seats

                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    new Alert(Alert.AlertType.INFORMATION, "Flight added successfully!").show();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Error adding flight.").show();
            }
        });

        // Wrap in StackPane to center the GridPane in window
        StackPane root = new StackPane(grid);
        root.setAlignment(Pos.CENTER); // Center in window

        Scene scene = new Scene(root, 600, 500);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }
}


















/*package admin;
import db.DBConnection;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class AdminFlightScreen extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Admin - Add Flight");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        // Input fields
        
        TextField nameField = new TextField();
        TextField sourceField = new TextField();
        TextField destField = new TextField();
        TextField depTimeField = new TextField();
        TextField arrTimeField = new TextField();
        TextField priceField = new TextField();
        TextField seatsField = new TextField();

        // Add labels + fields
        grid.add(new Label("Flight Name:"), 0, 0); grid.add(nameField, 1, 0);
        grid.add(new Label("Source:"), 0, 1); grid.add(sourceField, 1, 1);
        grid.add(new Label("Destination:"), 0, 2); grid.add(destField, 1, 2);
        grid.add(new Label("Departure Time:"), 0, 3); grid.add(depTimeField, 1, 3);
        grid.add(new Label("Arrival Time:"), 0, 4); grid.add(arrTimeField, 1, 4);
        grid.add(new Label("Price:"), 0, 5); grid.add(priceField, 1, 5);
        grid.add(new Label("Total Seats:"), 0, 6); grid.add(seatsField, 1, 6);
       

        Button addButton = new Button("Add Flight");
        grid.add(addButton, 1, 7);

        // Action: Add to DB
        addButton.setOnAction(e -> {
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO flights (flight_name, source, destination, departure_time, arrival_time, price, total_seats, available_seats) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
          
                stmt.setString(1, nameField.getText());
                stmt.setString(2, sourceField.getText());
                stmt.setString(3, destField.getText());
                stmt.setString(4, depTimeField.getText());
                stmt.setString(5, arrTimeField.getText());
                stmt.setDouble(6, Double.parseDouble(priceField.getText()));
                int seats = Integer.parseInt(seatsField.getText());
                stmt.setInt(7, seats);
                stmt.setInt(8, seats);  // available seats = total seats

                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    new Alert(Alert.AlertType.INFORMATION, "Flight added successfully!").show();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Error adding flight.").show();
            }
        });

        primaryStage.setScene(new Scene(grid, 450, 400));
        primaryStage.show();
        
        
       
    }
}*/
