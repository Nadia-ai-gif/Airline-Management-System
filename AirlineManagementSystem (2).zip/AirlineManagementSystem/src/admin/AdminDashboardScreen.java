package admin;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdminDashboardScreen {
    public void show() {
        Stage stage = new Stage();
        stage.setTitle("Admin Dashboard");

        // Create styled buttons
        Button addBtn = new Button("Add Flight");
        Button viewBtn = new Button("View Flights");
        Button editBtn = new Button("Edit Flight");
        Button deleteBtn = new Button("Delete Flight");

        // Add style classes
        addBtn.getStyleClass().add("button");
        viewBtn.getStyleClass().add("button");
        editBtn.getStyleClass().add("button");
        deleteBtn.getStyleClass().add("button");

        addBtn.setOnAction(e -> {
            try {
                new AdminFlightScreen().start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        viewBtn.setOnAction(e -> {
            try {
                new AdminViewFlightsScreen().start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        editBtn.setOnAction(e -> {
            try {
                new AdminEditFlightScreen().start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        deleteBtn.setOnAction(e -> {
            try {
                new AdminDeleteFlightScreen().start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox layout = new VBox(15, addBtn, viewBtn, editBtn, deleteBtn);
        layout.setAlignment(Pos.CENTER);
        layout.getStyleClass().add("root"); // dark gray background

        Scene scene = new Scene(layout, 300, 300);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        stage.setScene(scene);
        stage.show();
    }
}



















/*package admin;


import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdminDashboardScreen {
    public void show() {
        Stage stage = new Stage();
        stage.setTitle("Admin Dashboard");

        Button addBtn = new Button("Add Flight");
        Button viewBtn = new Button("View Flights");
        Button editBtn = new Button("Edit Flight");
        Button deleteBtn = new Button("Delete Flight");

        addBtn.setOnAction(e -> {
            try {
                new AdminFlightScreen().start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        viewBtn.setOnAction(e -> {
            try {
                new AdminViewFlightsScreen().start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        editBtn.setOnAction(e -> {
            try {
                new AdminEditFlightScreen().start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        deleteBtn.setOnAction(e -> {
            try {
                new AdminDeleteFlightScreen().start(new Stage());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox layout = new VBox(10, addBtn, viewBtn, editBtn, deleteBtn);
        layout.setSpacing(15);
        stage.setScene(new Scene(layout, 250, 250));
        stage.show();
    }
}*/
