

package gui;

import admin.AdminLoginScreen;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import passenger.PassengerLoginScreen;

public class MainScreen extends Application {
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Airline Management System");

        // --- Logo ---
        Image logoImage = new Image(getClass().getResource("/logo.png").toExternalForm());
        ImageView logoView = new ImageView(logoImage);
        logoView.setFitWidth(100);
        logoView.setPreserveRatio(true);

        HBox logoBox = new HBox(logoView);
        logoBox.setAlignment(Pos.TOP_RIGHT);
        logoBox.setPadding(new Insets(10));
        logoBox.getStyleClass().add("logo-top-right");

        // --- Title ---
        Label titleLabel = new Label("Choose role to proceed");
        titleLabel.getStyleClass().add("title-text");

        // --- Buttons ---
        Button adminButton = new Button("Admin");
        adminButton.getStyleClass().add("button");

        Button passengerButton = new Button("Passenger");
        passengerButton.getStyleClass().add("button");

        adminButton.setOnAction(e -> new AdminLoginScreen().show());
        passengerButton.setOnAction(e -> new PassengerLoginScreen().show());

        VBox centerBox = new VBox(15, titleLabel, adminButton, passengerButton);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.setPadding(new Insets(20));
        
     // …after you set up centerBox:
        centerBox.setTranslateY(-20);   // move it up by 20px
        BorderPane.setAlignment(centerBox, Pos.TOP_CENTER);  // keep it centered horizontally


        // --- Root layout ---
        BorderPane root = new BorderPane();
        root.setTop(logoBox);
        root.setCenter(centerBox);
        root.getStyleClass().add("main-screen");

        Scene scene = new Scene(root, 500, 350);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }
}






/*package gui;

import admin.AdminLoginScreen;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import passenger.PassengerLoginScreen;

public class MainScreen extends Application {
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Airline Management System");

        Button adminButton = new Button("Admin");
        Button passengerButton = new Button("Passenger");

        adminButton.setOnAction(e -> {
            try {
                new AdminLoginScreen().show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        passengerButton.setOnAction(e -> {
            try {
                new PassengerLoginScreen().show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox root = new VBox(20, adminButton, passengerButton);
        root.setAlignment(Pos.CENTER);

        Scene scene = new Scene(root, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}*/






/*package gui;

import admin.AdminLoginScreen;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import passenger.PassengerDashboardScreen; // <-- Add this once it's created

public class MainScreen extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Airline Management System");

        Button adminButton = new Button("Admin");
        Button passengerButton = new Button("Passenger");  // Renamed from "Customer"

        adminButton.setOnAction(e -> {
            try {
                new AdminLoginScreen().show();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        passengerButton.setOnAction(e -> {
            try {
            	//new PassengerDashboardScreen().show();
                new PassengerDashboardScreen().start(new Stage());  // Will create this soon
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox root = new VBox(20, adminButton, passengerButton);
        root.setAlignment(Pos.CENTER);

        Scene scene = new Scene(root, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
} */

